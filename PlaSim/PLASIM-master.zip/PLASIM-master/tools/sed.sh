sed -i -e "s/implicit real(kind=8) (a-h,o-z), integer(kind=8) (i-n)/include 'implicit.h'/" test.f

